import java.util.Scanner;

/**
 * Lab02a
 * Arda �nal 21903350
 * 16.10.2019
 */ 
public class Lab02a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables

      // program code
      System.out.println( "Start...");


      System.out.println( "End.");
   }

}